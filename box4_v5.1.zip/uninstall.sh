#!/system/bin/sh

rm -f /data/adb/service.d/box4_service.sh
